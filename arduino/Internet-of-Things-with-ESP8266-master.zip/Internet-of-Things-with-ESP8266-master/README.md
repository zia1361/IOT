# Internet-of-Things-with-ESP8266

This project develops a framework for IoT devices including:

Simple connections to Web services

Program an ESP8266 module in a “Thing”

Simple interface to smartphone

Programming stable and reactive “Things”

Automatically recover from a crash

A sleep mode to extend battery life

A new software has to  be loaded over the air

A tutorial is on youtube: https://www.youtube.com/playlist?list=PL3XBzmAj53Rl2vNyL9ucv87xnbUHzpSPw

